## [0.0.3] - 2026-01-04
### Hozzáadva
- Manuális keresés lehetősége
### Javítva
- 